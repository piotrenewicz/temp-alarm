import virtual_get
import inveo_get

dock = {
    "virtual": virtual_get,
    "inveo": inveo_get
}